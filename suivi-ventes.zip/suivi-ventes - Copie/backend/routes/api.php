<?php
/**
 * API pour vérifier s'il y a de nouvelles ventes
 * Utilisé pour la mise à jour en temps réel
 */

require_once '../controllers/AuthController.php';
require_once '../models/Sale.php';

// Vérifier l'authentification
$auth = new AuthController();
$auth->requireAuth();

header('Content-Type: application/json');

try {
    $currentUser = User::getCurrentUser();
    $isAdmin = $currentUser['role'] === 'admin';
    
    $sale = new Sale();
    
    // Récupérer le timestamp de la dernière vérification
    $lastCheck = $_GET['last_check'] ?? date('Y-m-d H:i:s', strtotime('-5 minutes'));
    
    // Construire les filtres
    $filters = [
        'date_debut' => $lastCheck
    ];
    
    // Pour les vendeurs, limiter aux propres ventes
    if (!$isAdmin) {
        $filters['current_user_only'] = true;
    }
    
    // Compter les nouvelles ventes
    $newSalesCount = $sale->count($filters);
    
    // Récupérer quelques détails sur les nouvelles ventes
    $recentSales = [];
    if ($newSalesCount > 0) {
        $filters['limit'] = 5;
        $filters['offset'] = 0;
        $recentSales = $sale->getAll($filters);
    }
    
    // Vérifier également les alertes de stock
    $product = new Product();
    $lowStockProducts = $product->getLowStock(10);
    $hasLowStockAlerts = count($lowStockProducts) > 0;
    
    // Notifications système
    $notifications = [];
    if ($isAdmin) {
        // Vérifier s'il y a des produits en rupture de stock
        if ($hasLowStockAlerts) {
            $notifications[] = [
                'type' => 'warning',
                'title' => 'Alerte Stock',
                'message' => count($lowStockProducts) . ' produit(s) en stock faible',
                'icon' => 'fas fa-exclamation-triangle'
            ];
        }
        
        // Vérifier les ventes du jour
        $todaySales = $sale->getTodaySales();
        $todayCount = count($todaySales);
        $todayTotal = array_sum(array_column($todaySales, 'total'));
        
        if ($todayCount === 0 && date('H') > 10) {
            $notifications[] = [
                'type' => 'info',
                'title' => 'Aucune vente aujourd\'hui',
                'message' => 'Aucune transaction enregistrée ce jour',
                'icon' => 'fas fa-info-circle'
            ];
        }
    }
    
    // Réponse
    $response = [
        'success' => true,
        'hasNewSales' => $newSalesCount > 0,
        'newSalesCount' => $newSalesCount,
        'recentSales' => $recentSales,
        'hasLowStockAlerts' => $hasLowStockAlerts,
        'lowStockCount' => count($lowStockProducts),
        'notifications' => $notifications,
        'timestamp' => date('Y-m-d H:i:s'),
        'serverTime' => date('H:i:s')
    ];
    
    // Ajouter des statistiques rapides pour le dashboard
    if (isset($_GET['include_stats']) && $_GET['include_stats'] === '1') {
        $todaySales = $sale->getTodaySales($isAdmin ? null : $currentUser['id']);
        $todayTotal = array_sum(array_column($todaySales, 'total'));
        
        $response['todayStats'] = [
            'salesCount' => count($todaySales),
            'totalAmount' => $todayTotal,
            'avgTransaction' => count($todaySales) > 0 ? $todayTotal / count($todaySales) : 0
        ];
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Erreur API check-new-sales: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erreur interne du serveur',
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

/**
 * Fonction utilitaire pour formatter les montants
 */
function formatAmount($amount) {
    return number_format($amount, 0, ',', ' ') . ' FCFA';
}

/**
 * Fonction pour calculer les tendances
 */
function calculateTrend($current, $previous) {
    if ($previous == 0) return 'new';
    
    $change = (($current - $previous) / $previous) * 100;
    
    if ($change > 10) return 'up';
    if ($change < -10) return 'down';
    return 'stable';
}
?>