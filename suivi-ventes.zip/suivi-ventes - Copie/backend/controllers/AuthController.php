<?php
require_once '../models/User.php';
require_once '../config/database.php';

class AuthController {
    private $user;

    public function __construct() {
        Config::startSession();
        $this->user = new User();
    }

    // Afficher la page de connexion
    public function showLogin() {
        if (User::isLoggedIn()) {
            header('Location: dashboard.php');
            exit();
        }
        
        $csrf_token = Config::generateCSRF();
        include '../pages/login.php';
    }

    // Traiter la connexion
    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: login.php');
            exit();
        }

        // Vérification CSRF
        if (!Config::validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->redirectWithError('Token de sécurité invalide');
            return;
        }

        $username = Config::sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validation des champs
        if (empty($username) || empty($password)) {
            $this->redirectWithError('Veuillez remplir tous les champs');
            return;
        }

        // Tentative de connexion
        $result = $this->user->login($username, $password);

        if ($result['success']) {
            // Redirection selon le rôle
            $redirectUrl = $result['user']['role'] === 'admin' ? 'admin-dashboard.php' : 'dashboard.php';
            header('Location: ' . $redirectUrl);
            exit();
        } else {
            $this->redirectWithError($result['message']);
        }
    }

    // Déconnexion
    public function logout() {
        User::logout();
        header('Location: login.php?message=Déconnexion réussie');
        exit();
    }

    // Vérifier l'authentification (middleware)
    public function requireAuth() {
        if (!User::isLoggedIn()) {
            header('Location: login.php?error=Veuillez vous connecter');
            exit();
        }
    }

    // Vérifier les permissions
    public function requirePermission($permission) {
        $this->requireAuth();
        
        if (!$this->user->hasPermission($permission)) {
            header('Location: dashboard.php?error=Accès non autorisé');
            exit();
        }
    }

    // Redirection avec message d'erreur
    private function redirectWithError($message) {
        header('Location: login.php?error=' . urlencode($message));
        exit();
    }

    // Créer un compte utilisateur (admin uniquement)
    public function createUser() {
        $this->requirePermission('cree_utilisateur');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Vérification CSRF
            if (!Config::validateCSRF($_POST['csrf_token'] ?? '')) {
                return ['success' => false, 'message' => 'Token de sécurité invalide'];
            }

            $username = Config::sanitizeInput($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $role = Config::sanitizeInput($_POST['role'] ?? 'vendeur');

            // Validations
            if (empty($username) || empty($password)) {
                return ['success' => false, 'message' => 'Tous les champs sont requis'];
            }

            if (strlen($password) < Config::PASSWORD_MIN_LENGTH) {
                return ['success' => false, 'message' => 'Le mot de passe doit contenir au moins ' . Config::PASSWORD_MIN_LENGTH . ' caractères'];
            }

            if ($password !== $confirmPassword) {
                return ['success' => false, 'message' => 'Les mots de passe ne correspondent pas'];
            }

            if (!in_array($role, ['admin', 'vendeur'])) {
                return ['success' => false, 'message' => 'Rôle invalide'];
            }

            return $this->user->create($username, $password, $role);
        }

        // Afficher le formulaire
        $csrf_token = Config::generateCSRF();
        include '../pages/users/add-user.php';
    }

    // API pour vérifier l'état de la session
    public function checkSession() {
        header('Content-Type: application/json');
        
        if (User::isLoggedIn()) {
            echo json_encode([
                'authenticated' => true,
                'user' => User::getCurrentUser(),
                'csrf_token' => Config::generateCSRF()
            ]);
        } else {
            echo json_encode(['authenticated' => false]);
        }
    }
}

// Routage simple
if (isset($_GET['action'])) {
    $auth = new AuthController();
    
    switch ($_GET['action']) {
        case 'login':
            $auth->handleLogin();
            break;
        case 'logout':
            $auth->logout();
            break;
        case 'create-user':
            $result = $auth->createUser();
            if (isset($result)) {
                header('Content-Type: application/json');
                echo json_encode($result);
            }
            break;
        case 'check-session':
            $auth->checkSession();
            break;
        default:
            $auth->showLogin();
    }
} else {
    $auth = new AuthController();
    $auth->showLogin();
}
?>