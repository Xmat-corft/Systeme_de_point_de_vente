<?php
require_once '../config/database.php';
require_once 'Product.php';

class Sale {
    private $conn;
    private $table = 'vente';

    public $idvente;
    public $datevente;
    public $quantite;
    public $prix_unitaire;
    public $NumProduit;
    public $idUtilisateur;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Créer une nouvelle vente
    public function create($productId, $quantity, $unitPrice, $userId, $date = null) {
        try {
            $this->conn->beginTransaction();
            
            // Vérifier le stock disponible
            $product = new Product();
            $productData = $product->getById($productId);
            
            if (!$productData) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Produit introuvable'];
            }
            
            if ($productData['quantiteProduit'] < $quantity) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Stock insuffisant. Stock disponible: ' . $productData['quantiteProduit'] . ' kg'];
            }
            
            // Date par défaut = aujourd'hui
            if ($date === null) {
                $date = date('Y-m-d');
            }
            
            // Créer la vente
            $query = "INSERT INTO " . $this->table . " (datevente, quantite, prix_unitaire, NumProduit, idUtilisateur) 
                     VALUES (:date, :quantity, :unit_price, :product_id, :user_id)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':unit_price', $unitPrice);
            $stmt->bindParam(':product_id', $productId);
            $stmt->bindParam(':user_id', $userId);
            
            if (!$stmt->execute()) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Erreur lors de l\'enregistrement de la vente'];
            }
            
            $saleId = $this->conn->lastInsertId();
            
            // Mettre à jour le stock
            $updateResult = $product->updateQuantity($productId, $quantity);
            if (!$updateResult['success']) {
                $this->conn->rollback();
                return $updateResult;
            }
            
            $this->conn->commit();
            
            return [
                'success' => true, 
                'message' => 'Vente enregistrée avec succès',
                'id' => $saleId,
                'total' => $quantity * $unitPrice
            ];
            
        } catch(Exception $e) {
            $this->conn->rollback();
            error_log("Erreur création vente: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de l\'enregistrement'];
        }
    }

    // Obtenir toutes les ventes avec filtres
    public function getAll($filters = []) {
        try {
            $query = "SELECT v.idvente, v.datevente, v.quantite, v.prix_unitaire,
                            (v.quantite * v.prix_unitaire) as total,
                            p.NomProduit, c.designation as categorie,
                            u.nomutilisateur as vendeur
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur
                     WHERE 1=1";
            
            $params = [];
            
            // Filtre par date de début
            if (!empty($filters['date_debut'])) {
                $query .= " AND v.datevente >= :date_debut";
                $params[':date_debut'] = $filters['date_debut'];
            }
            
            // Filtre par date de fin
            if (!empty($filters['date_fin'])) {
                $query .= " AND v.datevente <= :date_fin";
                $params[':date_fin'] = $filters['date_fin'];
            }
            
            // Filtre par produit
            if (!empty($filters['produit'])) {
                $query .= " AND v.NumProduit = :produit";
                $params[':produit'] = $filters['produit'];
            }
            
            // Filtre par catégorie
            if (!empty($filters['categorie'])) {
                $query .= " AND p.id_categorie = :categorie";
                $params[':categorie'] = $filters['categorie'];
            }
            
            // Filtre par vendeur (pour les admins)
            if (!empty($filters['vendeur'])) {
                $query .= " AND v.idUtilisateur = :vendeur";
                $params[':vendeur'] = $filters['vendeur'];
            }
            
            // Pour les vendeurs, voir seulement leurs ventes
            if (isset($filters['current_user_only']) && $filters['current_user_only']) {
                $query .= " AND v.idUtilisateur = :current_user";
                $params[':current_user'] = $_SESSION['user_id'];
            }
            
            $query .= " ORDER BY v.datevente DESC, v.idvente DESC";
            
            // Pagination
            if (isset($filters['limit']) && isset($filters['offset'])) {
                $query .= " LIMIT :limit OFFSET :offset";
                $params[':limit'] = (int)$filters['limit'];
                $params[':offset'] = (int)$filters['offset'];
            }
            
            $stmt = $this->conn->prepare($query);
            
            foreach ($params as $key => $value) {
                if (in_array($key, [':limit', ':offset'])) {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, $value);
                }
            }
            
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur récupération ventes: " . $e->getMessage());
            return [];
        }
    }

    // Obtenir une vente par ID
    public function getById($id) {
        try {
            $query = "SELECT v.idvente, v.datevente, v.quantite, v.prix_unitaire,
                            (v.quantite * v.prix_unitaire) as total,
                            p.NomProduit, p.NumProduit, c.designation as categorie,
                            u.nomutilisateur as vendeur, v.idUtilisateur
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur
                     WHERE v.idvente = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch(Exception $e) {
            error_log("Erreur récupération vente: " . $e->getMessage());
            return null;
        }
    }

    // Mettre à jour une vente
    public function update($id, $productId, $quantity, $unitPrice, $date) {
        try {
            $this->conn->beginTransaction();
            
            // Récupérer l'ancienne vente
            $oldSale = $this->getById($id);
            if (!$oldSale) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Vente introuvable'];
            }
            
            $product = new Product();
            
            // Si on change de produit ou de quantité, gérer les stocks
            if ($oldSale['NumProduit'] != $productId || $oldSale['quantite'] != $quantity) {
                // Remettre l'ancien stock
                $restoreQuery = "UPDATE produit SET quantiteProduit = quantiteProduit + :old_quantity 
                               WHERE NumProduit = :old_product";
                $restoreStmt = $this->conn->prepare($restoreQuery);
                $restoreStmt->bindParam(':old_quantity', $oldSale['quantite']);
                $restoreStmt->bindParam(':old_product', $oldSale['NumProduit']);
                $restoreStmt->execute();
                
                // Vérifier le nouveau stock
                $productData = $product->getById($productId);
                if (!$productData || $productData['quantiteProduit'] < $quantity) {
                    $this->conn->rollback();
                    return ['success' => false, 'message' => 'Stock insuffisant pour ce produit'];
                }
                
                // Déduire le nouveau stock
                $updateResult = $product->updateQuantity($productId, $quantity);
                if (!$updateResult['success']) {
                    $this->conn->rollback();
                    return $updateResult;
                }
            }
            
            // Mettre à jour la vente
            $query = "UPDATE " . $this->table . " 
                     SET datevente = :date, quantite = :quantity, prix_unitaire = :unit_price, 
                         NumProduit = :product_id
                     WHERE idvente = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':unit_price', $unitPrice);
            $stmt->bindParam(':product_id', $productId);
            
            if (!$stmt->execute()) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
            }
            
            $this->conn->commit();
            return ['success' => true, 'message' => 'Vente mise à jour avec succès'];
            
        } catch(Exception $e) {
            $this->conn->rollback();
            error_log("Erreur mise à jour vente: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
        }
    }

    // Supprimer une vente
    public function delete($id) {
        try {
            $this->conn->beginTransaction();
            
            // Récupérer la vente
            $sale = $this->getById($id);
            if (!$sale) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Vente introuvable'];
            }
            
            // Remettre le stock
            $restoreQuery = "UPDATE produit SET quantiteProduit = quantiteProduit + :quantity 
                           WHERE NumProduit = :product_id";
            $restoreStmt = $this->conn->prepare($restoreQuery);
            $restoreStmt->bindParam(':quantity', $sale['quantite']);
            $restoreStmt->bindParam(':product_id', $sale['NumProduit']);
            $restoreStmt->execute();
            
            // Supprimer la vente
            $query = "DELETE FROM " . $this->table . " WHERE idvente = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if (!$stmt->execute()) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Erreur lors de la suppression'];
            }
            
            $this->conn->commit();
            return ['success' => true, 'message' => 'Vente supprimée avec succès'];
            
        } catch(Exception $e) {
            $this->conn->rollback();
            error_log("Erreur suppression vente: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
        }
    }

    // Statistiques des ventes
    public function getStats($filters = []) {
        try {
            $stats = [];
            
            $whereClause = "WHERE 1=1";
            $params = [];
            
            // Filtre par date
            if (!empty($filters['date_debut'])) {
                $whereClause .= " AND v.datevente >= :date_debut";
                $params[':date_debut'] = $filters['date_debut'];
            }
            
            if (!empty($filters['date_fin'])) {
                $whereClause .= " AND v.datevente <= :date_fin";
                $params[':date_fin'] = $filters['date_fin'];
            }
            
            // Chiffre d'affaires total
            $query = "SELECT 
                        COUNT(*) as nb_ventes,
                        SUM(v.quantite * v.prix_unitaire) as ca_total,
                        SUM(v.quantite) as quantite_totale,
                        AVG(v.quantite * v.prix_unitaire) as panier_moyen
                     FROM " . $this->table . " v " . $whereClause;
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            $stats['global'] = $stmt->fetch();
            
            // Ventes par jour (derniers 30 jours)
            $query = "SELECT 
                        DATE(v.datevente) as date,
                        COUNT(*) as nb_ventes,
                        SUM(v.quantite * v.prix_unitaire) as ca_jour
                     FROM " . $this->table . " v 
                     WHERE v.datevente >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                     GROUP BY DATE(v.datevente)
                     ORDER BY date DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['par_jour'] = $stmt->fetchAll();
            
            // Produits les plus vendus
            $query = "SELECT 
                        p.NomProduit,
                        c.designation as categorie,
                        SUM(v.quantite) as quantite_vendue,
                        SUM(v.quantite * v.prix_unitaire) as ca_produit,
                        COUNT(*) as nb_transactions
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     " . $whereClause . "
                     GROUP BY v.NumProduit, p.NomProduit, c.designation
                     ORDER BY quantite_vendue DESC
                     LIMIT 10";
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            $stats['top_produits'] = $stmt->fetchAll();
            
            // Ventes par catégorie
            $query = "SELECT 
                        c.designation as categorie,
                        COUNT(*) as nb_ventes,
                        SUM(v.quantite) as quantite_totale,
                        SUM(v.quantite * v.prix_unitaire) as ca_categorie
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     " . $whereClause . "
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY ca_categorie DESC";
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            $stats['par_categorie'] = $stmt->fetchAll();
            
            // Ventes par vendeur
            $query = "SELECT 
                        u.nomutilisateur as vendeur,
                        COUNT(*) as nb_ventes,
                        SUM(v.quantite * v.prix_unitaire) as ca_vendeur
                     FROM " . $this->table . " v
                     LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur
                     " . $whereClause . "
                     GROUP BY v.idUtilisateur, u.nomutilisateur
                     ORDER BY ca_vendeur DESC";
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            $stats['par_vendeur'] = $stmt->fetchAll();
            
            // Évolution mensuelle (12 derniers mois)
            $query = "SELECT 
                        DATE_FORMAT(v.datevente, '%Y-%m') as mois,
                        COUNT(*) as nb_ventes,
                        SUM(v.quantite * v.prix_unitaire) as ca_mois
                     FROM " . $this->table . " v
                     WHERE v.datevente >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                     GROUP BY DATE_FORMAT(v.datevente, '%Y-%m')
                     ORDER BY mois DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['evolution_mensuelle'] = $stmt->fetchAll();
            
            return $stats;
            
        } catch(Exception $e) {
            error_log("Erreur statistiques ventes: " . $e->getMessage());
            return [];
        }
    }

    // Rapport des ventes pour une période
    public function getReport($filters = []) {
        try {
            $query = "SELECT 
                        DATE(v.datevente) as date,
                        p.NomProduit as produit,
                        c.designation as categorie,
                        v.quantite,
                        v.prix_unitaire,
                        (v.quantite * v.prix_unitaire) as total,
                        u.nomutilisateur as vendeur
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur
                     WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['date_debut'])) {
                $query .= " AND v.datevente >= :date_debut";
                $params[':date_debut'] = $filters['date_debut'];
            }
            
            if (!empty($filters['date_fin'])) {
                $query .= " AND v.datevente <= :date_fin";
                $params[':date_fin'] = $filters['date_fin'];
            }
            
            if (!empty($filters['produit'])) {
                $query .= " AND v.NumProduit = :produit";
                $params[':produit'] = $filters['produit'];
            }
            
            if (!empty($filters['categorie'])) {
                $query .= " AND p.id_categorie = :categorie";
                $params[':categorie'] = $filters['categorie'];
            }
            
            $query .= " ORDER BY v.datevente DESC, v.idvente DESC";
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur rapport ventes: " . $e->getMessage());
            return [];
        }
    }

    // Compter le nombre total de ventes (pour pagination)
    public function count($filters = []) {
        try {
            $query = "SELECT COUNT(*) as total
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['date_debut'])) {
                $query .= " AND v.datevente >= :date_debut";
                $params[':date_debut'] = $filters['date_debut'];
            }
            
            if (!empty($filters['date_fin'])) {
                $query .= " AND v.datevente <= :date_fin";
                $params[':date_fin'] = $filters['date_fin'];
            }
            
            if (!empty($filters['produit'])) {
                $query .= " AND v.NumProduit = :produit";
                $params[':produit'] = $filters['produit'];
            }
            
            if (!empty($filters['categorie'])) {
                $query .= " AND p.id_categorie = :categorie";
                $params[':categorie'] = $filters['categorie'];
            }
            
            if (isset($filters['current_user_only']) && $filters['current_user_only']) {
                $query .= " AND v.idUtilisateur = :current_user";
                $params[':current_user'] = $_SESSION['user_id'];
            }
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            
            return $stmt->fetch()['total'];
            
        } catch(Exception $e) {
            error_log("Erreur comptage ventes: " . $e->getMessage());
            return 0;
        }
    }

    // Ventes du jour
    public function getTodaySales($userId = null) {
        try {
            $query = "SELECT v.idvente, v.quantite, v.prix_unitaire,
                            (v.quantite * v.prix_unitaire) as total,
                            p.NomProduit, c.designation as categorie,
                            u.nomutilisateur as vendeur
                     FROM " . $this->table . " v
                     LEFT JOIN produit p ON v.NumProduit = p.NumProduit
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur
                     WHERE DATE(v.datevente) = CURDATE()";
            
            $params = [];
            
            if ($userId) {
                $query .= " AND v.idUtilisateur = :user_id";
                $params[':user_id'] = $userId;
            }
            
            $query .= " ORDER BY v.idvente DESC";
            
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur ventes du jour: " . $e->getMessage());
            return [];
        }
    }
}
?>