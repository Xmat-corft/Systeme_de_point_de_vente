<?php
require_once '../config/database.php';

class Category {
    private $conn;
    private $table = 'categorie';

    public $id_categorie;
    public $designation;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Créer une nouvelle catégorie
    public function create($designation) {
        try {
            // Vérifier si la catégorie existe déjà
            $checkQuery = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE designation = :designation";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':designation', $designation);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Cette catégorie existe déjà'];
            }

            $query = "INSERT INTO " . $this->table . " (designation) VALUES (:designation)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':designation', $designation);
            
            if ($stmt->execute()) {
                return [
                    'success' => true, 
                    'message' => 'Catégorie créée avec succès',
                    'id' => $this->conn->lastInsertId()
                ];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la création'];
            
        } catch(Exception $e) {
            error_log("Erreur création catégorie: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la création'];
        }
    }

    // Obtenir toutes les catégories
    public function getAll() {
        try {
            $query = "SELECT c.id_categorie, c.designation, COUNT(p.NumProduit) as nb_produits
                     FROM " . $this->table . " c
                     LEFT JOIN produit p ON c.id_categorie = p.id_categorie
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY c.designation";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur récupération catégories: " . $e->getMessage());
            return [];
        }
    }

    // Obtenir une catégorie par ID
    public function getById($id) {
        try {
            $query = "SELECT c.id_categorie, c.designation, COUNT(p.NumProduit) as nb_produits
                     FROM " . $this->table . " c
                     LEFT JOIN produit p ON c.id_categorie = p.id_categorie
                     WHERE c.id_categorie = :id
                     GROUP BY c.id_categorie, c.designation";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch(Exception $e) {
            error_log("Erreur récupération catégorie: " . $e->getMessage());
            return null;
        }
    }

    // Mettre à jour une catégorie
    public function update($id, $designation) {
        try {
            // Vérifier si le nom de la catégorie est déjà utilisé
            $checkQuery = "SELECT COUNT(*) as count FROM " . $this->table . " 
                          WHERE designation = :designation AND id_categorie != :id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':designation', $designation);
            $checkStmt->bindParam(':id', $id);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Cette désignation de catégorie est déjà utilisée'];
            }

            $query = "UPDATE " . $this->table . " SET designation = :designation WHERE id_categorie = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':designation', $designation);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Catégorie mise à jour avec succès'];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
            
        } catch(Exception $e) {
            error_log("Erreur mise à jour catégorie: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
        }
    }

    // Supprimer une catégorie
    public function delete($id) {
        try {
            // Vérifier si la catégorie a des produits associés
            $checkQuery = "SELECT COUNT(*) as count FROM produit WHERE id_categorie = :id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':id', $id);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Impossible de supprimer : cette catégorie contient des produits'];
            }

            $query = "DELETE FROM " . $this->table . " WHERE id_categorie = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Catégorie supprimée avec succès'];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
            
        } catch(Exception $e) {
            error_log("Erreur suppression catégorie: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
        }
    }

    // Obtenir les catégories pour un select
    public function getForSelect() {
        try {
            $query = "SELECT id_categorie, designation FROM " . $this->table . " ORDER BY designation";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur récupération catégories select: " . $e->getMessage());
            return [];
        }
    }

    // Statistiques des catégories
    public function getStats() {
        try {
            $stats = [];
            
            // Nombre total de catégories
            $query = "SELECT COUNT(*) as total FROM " . $this->table;
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['total_categories'] = $stmt->fetch()['total'];
            
            // Catégorie avec le plus de produits
            $query = "SELECT c.designation, COUNT(p.NumProduit) as nb_produits
                     FROM " . $this->table . " c
                     LEFT JOIN produit p ON c.id_categorie = p.id_categorie
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY nb_produits DESC
                     LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $topCategory = $stmt->fetch();
            $stats['top_category'] = $topCategory ? $topCategory : ['designation' => 'Aucune', 'nb_produits' => 0];
            
            // Répartition des produits par catégorie
            $query = "SELECT c.designation, COUNT(p.NumProduit) as nb_produits,
                            SUM(p.quantiteProduit * p.prix_par_Kg) as valeur_stock
                     FROM " . $this->table . " c
                     LEFT JOIN produit p ON c.id_categorie = p.id_categorie
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY nb_produits DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['distribution'] = $stmt->fetchAll();
            
            return $stats;
            
        } catch(Exception $e) {
            error_log("Erreur statistiques catégories: " . $e->getMessage());
            return [];
        }
    }

    // Rechercher des catégories
    public function search($term) {
        try {
            $query = "SELECT c.id_categorie, c.designation, COUNT(p.NumProduit) as nb_produits
                     FROM " . $this->table . " c
                     LEFT JOIN produit p ON c.id_categorie = p.id_categorie
                     WHERE c.designation LIKE :term
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY c.designation";
            
            $stmt = $this->conn->prepare($query);
            $searchTerm = '%' . $term . '%';
            $stmt->bindParam(':term', $searchTerm);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur recherche catégories: " . $e->getMessage());
            return [];
        }
    }
}
?>