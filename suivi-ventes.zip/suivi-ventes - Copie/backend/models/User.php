<?php
require_once '../config/database.php';

class User {
    private $conn;
    private $table = 'utilisateur';

    public $idUtilisateur;
    public $nomutilisateur;
    public $motdepasse;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Authentification
    public function login($username, $password) {
        try {
            $query = "SELECT u.idUtilisateur, u.nomutilisateur, u.motdepasse, r.NomRole 
                     FROM " . $this->table . " u
                     LEFT JOIN roleutilisateur ru ON u.idUtilisateur = ru.idUtilisateur
                     LEFT JOIN role r ON ru.idRole = r.idRole
                     WHERE u.nomutilisateur = :username";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            
            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch();
                
                if (password_verify($password, $user['motdepasse'])) {
                    // Connexion réussie
                    $_SESSION['user_id'] = $user['idUtilisateur'];
                    $_SESSION['username'] = $user['nomutilisateur'];
                    $_SESSION['role'] = $user['NomRole'] ?? 'vendeur';
                    $_SESSION['login_time'] = time();
                    
                    return [
                        'success' => true,
                        'user' => [
                            'id' => $user['idUtilisateur'],
                            'username' => $user['nomutilisateur'],
                            'role' => $user['NomRole'] ?? 'vendeur'
                        ]
                    ];
                }
            }
            
            return ['success' => false, 'message' => 'Identifiants invalides'];
            
        } catch(Exception $e) {
            error_log("Erreur login: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur de connexion'];
        }
    }

    // Vérifier les permissions
    public function hasPermission($permission) {
        if (!isset($_SESSION['user_id'])) {
            return false;
        }

        try {
            $query = "SELECT COUNT(*) as count
                     FROM permission p
                     INNER JOIN rolepermission rp ON p.idPermission = rp.idPermission
                     INNER JOIN roleutilisateur ru ON rp.idRole = ru.idRole
                     WHERE ru.idUtilisateur = :user_id AND p.typePermission = :permission";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->bindParam(':permission', $permission);
            $stmt->execute();
            
            $result = $stmt->fetch();
            return $result['count'] > 0;
            
        } catch(Exception $e) {
            error_log("Erreur permission: " . $e->getMessage());
            return false;
        }
    }

    // Créer un utilisateur (admin uniquement)
    public function create($username, $password, $role = 'vendeur') {
        try {
            // Vérifier si l'utilisateur existe déjà
            $checkQuery = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE nomutilisateur = :username";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':username', $username);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Nom d\'utilisateur déjà existant'];
            }

            $this->conn->beginTransaction();
            
            // Créer l'utilisateur
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO " . $this->table . " (nomutilisateur, motdepasse) VALUES (:username, :password)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashedPassword);
            $stmt->execute();
            
            $userId = $this->conn->lastInsertId();
            
            // Assigner le rôle
            $roleQuery = "SELECT idRole FROM role WHERE NomRole = :role";
            $roleStmt = $this->conn->prepare($roleQuery);
            $roleStmt->bindParam(':role', $role);
            $roleStmt->execute();
            $roleData = $roleStmt->fetch();
            
            if ($roleData) {
                $roleUserQuery = "INSERT INTO roleutilisateur (idUtilisateur, idRole) VALUES (:user_id, :role_id)";
                $roleUserStmt = $this->conn->prepare($roleUserQuery);
                $roleUserStmt->bindParam(':user_id', $userId);
                $roleUserStmt->bindParam(':role_id', $roleData['idRole']);
                $roleUserStmt->execute();
            }
            
            $this->conn->commit();
            return ['success' => true, 'message' => 'Utilisateur créé avec succès'];
            
        } catch(Exception $e) {
            $this->conn->rollback();
            error_log("Erreur création utilisateur: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la création'];
        }
    }

    // Lister tous les utilisateurs
    public function getAll() {
        try {
            $query = "SELECT u.idUtilisateur, u.nomutilisateur, r.NomRole
                     FROM " . $this->table . " u
                     LEFT JOIN roleutilisateur ru ON u.idUtilisateur = ru.idUtilisateur
                     LEFT JOIN role r ON ru.idRole = r.idRole
                     ORDER BY u.nomutilisateur";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur récupération utilisateurs: " . $e->getMessage());
            return [];
        }
    }

    // Supprimer un utilisateur
    public function delete($id) {
        try {
            $query = "DELETE FROM " . $this->table . " WHERE idUtilisateur = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            return ['success' => true, 'message' => 'Utilisateur supprimé'];
            
        } catch(Exception $e) {
            error_log("Erreur suppression utilisateur: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
        }
    }

    // Vérifier si l'utilisateur est connecté
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['login_time']) 
               && (time() - $_SESSION['login_time']) < Config::SESSION_LIFETIME;
    }

    // Déconnexion
    public static function logout() {
        session_destroy();
        return true;
    }

    // Obtenir les informations de l'utilisateur connecté
    public static function getCurrentUser() {
        if (self::isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'role' => $_SESSION['role']
            ];
        }
        return null;
    }
}
?>