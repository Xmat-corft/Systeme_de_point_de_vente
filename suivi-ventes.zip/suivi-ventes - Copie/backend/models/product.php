<?php
require_once '../config/database.php';

class Product {
    private $conn;
    private $table = 'produit';

    public $NumProduit;
    public $NomProduit;
    public $quantiteProduit;
    public $prix_par_Kg;
    public $id_categorie;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Créer un nouveau produit
    public function create($name, $quantity, $price, $categoryId) {
        try {
            // Vérifier si le produit existe déjà
            $checkQuery = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE NomProduit = :name";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':name', $name);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Ce produit existe déjà'];
            }

            $query = "INSERT INTO " . $this->table . " (NomProduit, quantiteProduit, prix_par_Kg, id_categorie) 
                     VALUES (:name, :quantity, :price, :category_id)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':category_id', $categoryId);
            
            if ($stmt->execute()) {
                return [
                    'success' => true, 
                    'message' => 'Produit créé avec succès',
                    'id' => $this->conn->lastInsertId()
                ];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la création'];
            
        } catch(Exception $e) {
            error_log("Erreur création produit: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la création'];
        }
    }

    // Obtenir tous les produits avec leurs catégories
    public function getAll($search = '', $categoryId = null) {
        try {
            $query = "SELECT p.NumProduit, p.NomProduit, p.quantiteProduit, p.prix_par_Kg, 
                            c.designation as categorie, p.id_categorie
                     FROM " . $this->table . " p
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     WHERE 1=1";
            
            $params = [];
            
            if (!empty($search)) {
                $query .= " AND p.NomProduit LIKE :search";
                $params[':search'] = '%' . $search . '%';
            }
            
            if ($categoryId !== null && $categoryId !== '') {
                $query .= " AND p.id_categorie = :category_id";
                $params[':category_id'] = $categoryId;
            }
            
            $query .= " ORDER BY p.NomProduit";
            
            $stmt = $this->conn->prepare($query);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur récupération produits: " . $e->getMessage());
            return [];
        }
    }

    // Obtenir un produit par ID
    public function getById($id) {
        try {
            $query = "SELECT p.NumProduit, p.NomProduit, p.quantiteProduit, p.prix_par_Kg, 
                            c.designation as categorie, p.id_categorie
                     FROM " . $this->table . " p
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     WHERE p.NumProduit = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch(Exception $e) {
            error_log("Erreur récupération produit: " . $e->getMessage());
            return null;
        }
    }

    // Mettre à jour un produit
    public function update($id, $name, $quantity, $price, $categoryId) {
        try {
            // Vérifier si le nom du produit est déjà utilisé par un autre produit
            $checkQuery = "SELECT COUNT(*) as count FROM " . $this->table . " 
                          WHERE NomProduit = :name AND NumProduit != :id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':name', $name);
            $checkStmt->bindParam(':id', $id);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Ce nom de produit est déjà utilisé'];
            }

            $query = "UPDATE " . $this->table . " 
                     SET NomProduit = :name, quantiteProduit = :quantity, 
                         prix_par_Kg = :price, id_categorie = :category_id
                     WHERE NumProduit = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':category_id', $categoryId);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Produit mis à jour avec succès'];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
            
        } catch(Exception $e) {
            error_log("Erreur mise à jour produit: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
        }
    }

    // Supprimer un produit
    public function delete($id) {
        try {
            // Vérifier si le produit a des ventes associées
            $checkQuery = "SELECT COUNT(*) as count FROM vente WHERE NumProduit = :id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':id', $id);
            $checkStmt->execute();
            
            if ($checkStmt->fetch()['count'] > 0) {
                return ['success' => false, 'message' => 'Impossible de supprimer : ce produit a des ventes associées'];
            }

            $query = "DELETE FROM " . $this->table . " WHERE NumProduit = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Produit supprimé avec succès'];
            }
            
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
            
        } catch(Exception $e) {
            error_log("Erreur suppression produit: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la suppression'];
        }
    }

    // Mettre à jour la quantité (pour les ventes)
    public function updateQuantity($id, $quantity) {
        try {
            $query = "UPDATE " . $this->table . " SET quantiteProduit = quantiteProduit - :quantity 
                     WHERE NumProduit = :id AND quantiteProduit >= :quantity";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':quantity', $quantity);
            
            if ($stmt->execute() && $stmt->rowCount() > 0) {
                return ['success' => true, 'message' => 'Stock mis à jour'];
            }
            
            return ['success' => false, 'message' => 'Stock insuffisant'];
            
        } catch(Exception $e) {
            error_log("Erreur mise à jour stock: " . $e->getMessage());
            return ['success' => false, 'message' => 'Erreur lors de la mise à jour du stock'];
        }
    }

    // Obtenir les produits en rupture de stock
    public function getLowStock($threshold = 10) {
        try {
            $query = "SELECT p.NumProduit, p.NomProduit, p.quantiteProduit, 
                            c.designation as categorie
                     FROM " . $this->table . " p
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     WHERE p.quantiteProduit <= :threshold
                     ORDER BY p.quantiteProduit ASC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':threshold', $threshold);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur produits en rupture: " . $e->getMessage());
            return [];
        }
    }

    // Statistiques des produits
    public function getStats() {
        try {
            $stats = [];
            
            // Nombre total de produits
            $query = "SELECT COUNT(*) as total FROM " . $this->table;
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['total_products'] = $stmt->fetch()['total'];
            
            // Valeur totale du stock
            $query = "SELECT SUM(quantiteProduit * prix_par_Kg) as total_value FROM " . $this->table;
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['total_stock_value'] = $stmt->fetch()['total_value'] ?? 0;
            
            // Produits en rupture
            $query = "SELECT COUNT(*) as low_stock FROM " . $this->table . " WHERE quantiteProduit <= 10";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['low_stock_count'] = $stmt->fetch()['low_stock'];
            
            // Répartition par catégorie
            $query = "SELECT c.designation, COUNT(p.NumProduit) as count 
                     FROM categorie c
                     LEFT JOIN " . $this->table . " p ON c.id_categorie = p.id_categorie
                     GROUP BY c.id_categorie, c.designation
                     ORDER BY count DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $stats['by_category'] = $stmt->fetchAll();
            
            return $stats;
            
        } catch(Exception $e) {
            error_log("Erreur statistiques produits: " . $e->getMessage());
            return [];
        }
    }

    // Recherche avancée de produits
    public function search($filters = []) {
        try {
            $query = "SELECT p.NumProduit, p.NomProduit, p.quantiteProduit, p.prix_par_Kg,
                            c.designation as categorie, p.id_categorie
                     FROM " . $this->table . " p
                     LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
                     WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['name'])) {
                $query .= " AND p.NomProduit LIKE :name";
                $params[':name'] = '%' . $filters['name'] . '%';
            }
            
            if (!empty($filters['category'])) {
                $query .= " AND p.id_categorie = :category";
                $params[':category'] = $filters['category'];
            }
            
            if (isset($filters['min_price']) && $filters['min_price'] !== '') {
                $query .= " AND p.prix_par_Kg >= :min_price";
                $params[':min_price'] = $filters['min_price'];
            }
            
            if (isset($filters['max_price']) && $filters['max_price'] !== '') {
                $query .= " AND p.prix_par_Kg <= :max_price";
                $params[':max_price'] = $filters['max_price'];
            }
            
            if (isset($filters['min_quantity']) && $filters['min_quantity'] !== '') {
                $query .= " AND p.quantiteProduit >= :min_quantity";
                $params[':min_quantity'] = $filters['min_quantity'];
            }
            
            $query .= " ORDER BY p.NomProduit";
            
            $stmt = $this->conn->prepare($query);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch(Exception $e) {
            error_log("Erreur recherche produits: " . $e->getMessage());
            return [];
        }
    }
}
?>