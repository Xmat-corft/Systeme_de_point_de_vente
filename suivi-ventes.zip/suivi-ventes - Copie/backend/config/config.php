<?php
/**
 * Script d'installation automatique du système de suivi des ventes
 * À exécuter une seule fois lors de la première installation
 */

// Vérifier si l'installation a déjà été effectuée
if (file_exists('config/installed.lock')) {
    die('⚠️ L\'installation a déjà été effectuée. Supprimez le fichier config/installed.lock pour réinstaller.');
}

$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Traitement des étapes
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($_POST['step']) {
        case '2':
            $result = checkRequirements();
            if ($result['success']) {
                $step = 3;
            } else {
                $errors = $result['errors'];
            }
            break;
            
        case '3':
            $result = configureDatabase($_POST);
            if ($result['success']) {
                $step = 4;
                $success[] = 'Configuration de la base de données réussie';
            } else {
                $errors = $result['errors'];
            }
            break;
            
        case '4':
            $result = createAdminUser($_POST);
            if ($result['success']) {
                $step = 5;
                $success[] = 'Utilisateur administrateur créé';
            } else {
                $errors = $result['errors'];
            }
            break;
            
        case '5':
            $result = finalizeInstallation();
            if ($result['success']) {
                $step = 6;
                $success[] = 'Installation terminée avec succès !';
            } else {
                $errors = $result['errors'];
            }
            break;
    }
}

/**
 * Vérifier les prérequis système
 */
function checkRequirements() {
    $errors = [];
    
    // Version PHP
    if (version_compare(PHP_VERSION, '8.0.0', '<')) {
        $errors[] = 'PHP 8.0+ requis. Version actuelle: ' . PHP_VERSION;
    }
    
    // Extensions PHP
    $requiredExtensions = ['pdo', 'pdo_mysql', 'mbstring', 'json', 'session'];
    foreach ($requiredExtensions as $ext) {
        if (!extension_loaded($ext)) {
            $errors[] = "Extension PHP manquante: $ext";
        }
    }
    
    // Permissions des dossiers
    $directories = ['config', 'logs', 'uploads'];
    foreach ($directories as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        if (!is_writable($dir)) {
            $errors[] = "Dossier non accessible en écriture: $dir";
        }
    }
    
    return ['success' => empty($errors), 'errors' => $errors];
}

/**
 * Configurer la base de données
 */
function configureDatabase($data) {
    $errors = [];
    
    try {
        // Tester la connexion
        $host = $data['db_host'] ?? 'localhost';
        $dbname = $data['db_name'] ?? 'suivi_vente';
        $username = $data['db_user'] ?? 'root';
        $password = $data['db_pass'] ?? '';
        
        $pdo = new PDO(
            "mysql:host=$host;charset=utf8mb4",
            $username,
            $password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        // Créer la base de données si elle n'existe pas
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci");
        $pdo->exec("USE `$dbname`");
        
        // Exécuter le script de création des tables
        $sql = file_get_contents('database/suivi_vente.sql');
        if ($sql) {
            $pdo->exec($sql);
        }
        
        // Exécuter le script de configuration avancée
        $setupSql = file_get_contents('database/setup.sql');
        if ($setupSql) {
            $pdo->exec($setupSql);
        }
        
        // Sauvegarder la configuration
        $configContent = generateDatabaseConfig($host, $dbname, $username, $password);
        file_put_contents('config/database.php', $configContent);
        
        return ['success' => true];
        
    } catch (Exception $e) {
        $errors[] = 'Erreur de base de données: ' . $e->getMessage();
        return ['success' => false, 'errors' => $errors];
    }
}

/**
 * Créer l'utilisateur administrateur
 */
function createAdminUser($data) {
    $errors = [];
    
    try {
        require_once 'config/database.php';
        
        $database = new Database();
        $conn = $database->getConnection();
        
        $username = $data['admin_user'] ?? 'admin';
        $password = $data['admin_pass'] ?? '';
        $email = $data['admin_email'] ?? '';
        
        if (strlen($password) < 6) {
            $errors[] = 'Le mot de passe doit contenir au moins 6 caractères';
            return ['success' => false, 'errors' => $errors];
        }
        
        // Hasher le mot de passe
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Créer l'utilisateur
        $query = "INSERT INTO utilisateur (nomutilisateur, motdepasse, email, first_name, last_name) 
                 VALUES (:username, :password, :email, 'Super', 'Admin')";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'username' => $username,
            'password' => $hashedPassword,
            'email' => $email
        ]);
        
        $userId = $conn->lastInsertId();
        
        // Assigner le rôle admin
        $roleQuery = "INSERT INTO roleutilisateur (idUtilisateur, idRole) 
                     SELECT :user_id, idRole FROM role WHERE NomRole = 'admin'";
        $roleStmt = $conn->prepare($roleQuery);
        $roleStmt->execute(['user_id' => $userId]);
        
        return ['success' => true];
        
    } catch (Exception $e) {
        $errors[] = 'Erreur création utilisateur: ' . $e->getMessage();
        return ['success' => false, 'errors' => $errors];
    }
}

/**
 * Finaliser l'installation
 */
function finalizeInstallation() {
    try {
        // Créer le fichier de verrou
        file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
        
        // Créer le fichier .htaccess si nécessaire
        if (!file_exists('public/.htaccess')) {
            $htaccessContent = generateHtaccessContent();
            file_put_contents('public/.htaccess', $htaccessContent);
        }
        
        // Configurer les permissions finales
        chmod('config', 0750);
        chmod('config/database.php', 0640);
        
        return ['success' => true];
        
    } catch (Exception $e) {
        return ['success' => false, 'errors' => ['Erreur finalisation: ' . $e->getMessage()]];
    }
}

/**
 * Générer le contenu du fichier de configuration de base de données
 */
function generateDatabaseConfig($host, $dbname, $username, $password) {
    return "<?php
/**
 * Configuration de la base de données
 * Généré automatiquement le " . date('Y-m-d H:i:s') . "
 */

class Database {
    private \$host = '$host';
    private \$db_name = '$dbname';
    private \$username = '$username';
    private \$password = '$password';
    private \$conn;

    public function getConnection() {
        \$this->conn = null;
        
        try {
            \$this->conn = new PDO(
                \"mysql:host=\" . \$this->host . \";dbname=\" . \$this->db_name . \";charset=utf8mb4\",
                \$this->username,
                \$this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException \$e) {
            error_log(\"Erreur de connexion: \" . \$e->getMessage());
            throw new Exception(\"Erreur de connexion à la base de données\");
        }
        
        return \$this->conn;
    }

    public function closeConnection() {
        \$this->conn = null;
    }
}

// Configuration générale
class Config {
    const SITE_NAME = \"Système de Suivi des Ventes\";
    const BASE_URL = \"http://\" . \$_SERVER['HTTP_HOST'] . \"/\" . dirname(\$_SERVER['SCRIPT_NAME']) . \"/\";
    const SESSION_LIFETIME = 3600;
    const PASSWORD_MIN_LENGTH = 6;
    const MAX_LOGIN_ATTEMPTS = 3;
    const LOCKOUT_TIME = 900;
    
    public static function startSession() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', 1);
            ini_set('session.cookie_secure', isset(\$_SERVER['HTTPS']));
            ini_set('session.use_strict_mode', 1);
            session_start();
        }
    }
    
    public static function sanitizeInput(\$input) {
        return htmlspecialchars(strip_tags(trim(\$input)), ENT_QUOTES, 'UTF-8');
    }
    
    public static function validateCSRF(\$token) {
        return isset(\$_SESSION['csrf_token']) && hash_equals(\$_SESSION['csrf_token'], \$token);
    }
    
    public static function generateCSRF() {
        if (!isset(\$_SESSION['csrf_token'])) {
            \$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return \$_SESSION['csrf_token'];
    }
}
?>";
}

/**
 * Générer le contenu du fichier .htaccess
 */
function generateHtaccessContent() {
    return "# Configuration Apache pour le système de suivi des ventes
RewriteEngine On

# Redirection vers index.php
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

# Sécurité
<Files \"*.php\">
    Order allow,deny
    Allow from all
</Files>

# Bloquer l'accès aux fichiers sensibles
<FilesMatch \"\.(htaccess|htpasswd|ini|log|sh|inc|bak)$\">
    Order deny,allow
    Deny from all
</FilesMatch>

# Bloquer l'accès aux dossiers de configuration
<Directory \"../config\">
    Order deny,allow
    Deny from all
</Directory>

<Directory \"../database\">
    Order deny,allow
    Deny from all
</Directory>

# Headers de sécurité
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection \"1; mode=block\"
    Header always set Referrer-Policy \"strict-origin-when-cross-origin\"
</IfModule>

# Compression GZIP
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Cache des ressources statiques
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css \"access plus 1 month\"
    ExpiresByType application/javascript \"access plus 1 month\"
    ExpiresByType image/png \"access plus 1 month\"
    ExpiresByType image/jpg \"access plus 1 month\"
    ExpiresByType image/jpeg \"access plus 1 month\"
    ExpiresByType image/gif \"access plus 1 month\"
    ExpiresByType image/ico \"access plus 1 month\"
    ExpiresByType image/icon \"access plus 1 month\"
    ExpiresByType text/x-icon \"access plus 1 month\"
    ExpiresByType image/x-icon \"access plus 1 month\"
    ExpiresByType application/pdf \"access plus 1 month\"
    ExpiresByType application/x-shockwave-flash \"access plus 1 month\"
</IfModule>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Système de Suivi des Ventes</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .install-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
            overflow: hidden;
        }

        .install-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .install-header h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .install-header p {
            opacity: 0.9;
        }

        .install-content {
            padding: 2rem;
        }

        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding: 0 1rem;
        }

        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            position: relative;
        }

        .step:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 20px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: #e5e7eb;
            z-index: 1;
        }

        .step.active:not(:last-child)::after {
            background: #667eea;
        }

        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e5e7eb;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-bottom: 8px;
            position: relative;
            z-index: 2;
        }

        .step.active .step-number {
            background: #667eea;
            color: white;
        }

        .step.completed .step-number {
            background: #10b981;
            color: white;
        }

        .step-label {
            font-size: 0.8rem;
            color: #666;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #374151;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-success:hover {
            background: #059669;
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .requirement {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #e5e7eb;
        }

        .requirement:last-child {
            border-bottom: none;
        }

        .requirement-status {
            font-weight: 600;
        }

        .status-ok {
            color: #10b981;
        }

        .status-error {
            color: #ef4444;
        }

        .actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: #e5e7eb;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: width 0.3s ease;
        }

        @media (max-width: 768px) {
            .step-indicator {
                flex-direction: column;
                gap: 1rem;
            }

            .step:not(:last-child)::after {
                display: none;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="install-header">
            <h1><i class="fas fa-cog"></i> Installation</h1>
            <p>Système de Suivi des Ventes - BTS Informatique</p>
        </div>

        <div class="install-content">
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo ($step / 6) * 100; ?>%;"></div>
            </div>

            <div class="step-indicator">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 1 ? '✓' : '1'; ?></div>
                    <div class="step-label">Bienvenue</div>
                </div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 2 ? '✓' : '2'; ?></div>
                    <div class="step-label">Prérequis</div>
                </div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 3 ? '✓' : '3'; ?></div>
                    <div class="step-label">Base de données</div>
                </div>
                <div class="step <?php echo $step >= 4 ? 'active' : ''; ?> <?php echo $step > 4 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 4 ? '✓' : '4'; ?></div>
                    <div class="step-label">Administrateur</div>
                </div>
                <div class="step <?php echo $step >= 5 ? 'active' : ''; ?> <?php echo $step > 5 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 5 ? '✓' : '5'; ?></div>
                    <div class="step-label">Configuration</div>
                </div>
                <div class="step <?php echo $step >= 6 ? 'active' : ''; ?>">
                    <div class="step-number"><?php echo $step >= 6 ? '✓' : '6'; ?></div>
                    <div class="step-label">Terminé</div>
                </div>
            </div>

            <?php if (!empty($errors)): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <?php foreach ($success as $msg): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo htmlspecialchars($msg); ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if ($step == 1): ?>
                <h2>Bienvenue dans l'installation</h2>
                <p style="margin: 1rem 0;">
                    Cet assistant va vous guider pour installer le système de suivi des ventes.
                    L'installation se déroule en plusieurs étapes :
                </p>
                <ul style="margin: 1rem 0 1rem 2rem;">
                    <li>Vérification des prérequis système</li>
                    <li>Configuration de la base de données</li>
                    <li>Création du compte administrateur</li>
                    <li>Configuration finale</li>
                </ul>
                <p style="color: #666;">
                    Assurez-vous d'avoir les informations de connexion à votre base de données MySQL.
                </p>

                <div class="actions">
                    <form method="POST">
                        <input type="hidden" name="step" value="2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-arrow-right"></i>
                            Commencer l'installation
                        </button>
                    </form>
                </div>

            <?php elseif ($step == 2): ?>
                <h2>Vérification des prérequis</h2>
                <p style="margin-bottom: 1.5rem;">
                    Vérification de la compatibilité de votre serveur :
                </p>

                <div class="requirement">
                    <span>Version PHP (≥ 8.0)</span>
                    <span class="requirement-status <?php echo version_compare(PHP_VERSION, '8.0.0', '>=') ? 'status-ok' : 'status-error'; ?>">
                        <?php echo version_compare(PHP_VERSION, '8.0.0', '>=') ? '✓ ' . PHP_VERSION : '✗ ' . PHP_VERSION; ?>
                    </span>
                </div>

                <?php foreach (['pdo', 'pdo_mysql', 'mbstring', 'json', 'session'] as $ext): ?>
                <div class="requirement">
                    <span>Extension <?php echo $ext; ?></span>
                    <span class="requirement-status <?php echo extension_loaded($ext) ? 'status-ok' : 'status-error'; ?>">
                        <?php echo extension_loaded($ext) ? '✓ Installée' : '✗ Manquante'; ?>
                    </span>
                </div>
                <?php endforeach; ?>

                <?php foreach (['config', 'logs', 'uploads'] as $dir): ?>
                <div class="requirement">
                    <span>Dossier <?php echo $dir; ?> accessible</span>
                    <span class="requirement-status <?php echo is_writable($dir) || (!is_dir($dir) && is_writable('.')) ? 'status-ok' : 'status-error'; ?>">
                        <?php echo is_writable($dir) || (!is_dir($dir) && is_writable('.')) ? '✓ OK' : '✗ Erreur'; ?>
                    </span>
                </div>
                <?php endforeach; ?>

                <div class="actions">
                    <form method="POST">
                        <input type="hidden" name="step" value="2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-refresh"></i>
                            Vérifier à nouveau
                        </button>
                    </form>
                </div>

            <?php elseif ($step == 3): ?>
                <h2>Configuration de la base de données</h2>
                <p style="margin-bottom: 1.5rem;">
                    Saisissez les informations de connexion à votre base de données MySQL :
                </p>

                <form method="POST">
                    <input type="hidden" name="step" value="3">
                    
                    <div class="form-group">
                        <label for="db_host">Serveur de base de données</label>
                        <input type="text" id="db_host" name="db_host" value="localhost" required>
                    </div>

                    <div class="form-group">
                        <label for="db_name">Nom de la base de données</label>
                        <input type="text" id="db_name" name="db_name" value="suivi_vente" required>
                    </div>

                    <div class="form-group">
                        <label for="db_user">Nom d'utilisateur</label>
                        <input type="text" id="db_user" name="db_user" value="root" required>
                    </div>

                    <div class="form-group">
                        <label for="db_pass">Mot de passe</label>
                        <input type="password" id="db_pass" name="db_pass">
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-database"></i>
                            Configurer la base de données
                        </button>
                    </div>
                </form>

            <?php elseif ($step == 4): ?>
                <h2>Création du compte administrateur</h2>
                <p style="margin-bottom: 1.5rem;">
                    Créez votre compte administrateur principal :
                </p>

                <form method="POST">
                    <input type="hidden" name="step" value="4">
                    
                    <div class="form-group">
                        <label for="admin_user">Nom d'utilisateur</label>
                        <input type="text" id="admin_user" name="admin_user" value="admin" required>
                    </div>

                    <div class="form-group">
                        <label for="admin_pass">Mot de passe</label>
                        <input type="password" id="admin_pass" name="admin_pass" required minlength="6">
                    </div>

                    <div class="form-group">
                        <label for="admin_email">Email (optionnel)</label>
                        <input type="email" id="admin_email" name="admin_email">
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i>
                            Créer l'administrateur
                        </button>
                    </div>
                </form>

            <?php elseif ($step == 5): ?>
                <h2>Configuration finale</h2>
                <p style="margin-bottom: 1.5rem;">
                    Finalisation de l'installation et configuration des paramètres de sécurité :
                </p>

                <ul style="margin: 1rem 0 1rem 2rem;">
                    <li>✓ Création du fichier de verrou d'installation</li>
                    <li>✓ Configuration des permissions de sécurité</li>
                    <li>✓ Génération du fichier .htaccess</li>
                    <li>✓ Configuration des paramètres système</li>
                </ul>

                <div class="actions">
                    <form method="POST">
                        <input type="hidden" name="step" value="5">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i>
                            Finaliser l'installation
                        </button>
                    </form>
                </div>

            <?php elseif ($step == 6): ?>
                <h2>🎉 Installation terminée !</h2>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    Le système de suivi des ventes a été installé avec succès !
                </div>

                <h3 style="margin: 1.5rem 0 1rem 0;">Informations importantes :</h3>
                <ul style="margin: 1rem 0 1rem 2rem;">
                    <li><strong>URL d'accès :</strong> <a href="public/" target="_blank">Accéder à l'application</a></li>
                    <li><strong>Compte administrateur :</strong> Utilisez les identifiants que vous avez créés</li>
                    <li><strong>Sécurité :</strong> Supprimez ce fichier d'installation pour des raisons de sécurité</li>
                </ul>

                <h3 style="margin: 1.5rem 0 1rem 0;">Prochaines étapes :</h3>
                <ul style="margin: 1rem 0 1rem 2rem;">
                    <li>Connectez-vous avec votre compte administrateur</li>
                    <li>Créez les catégories de produits</li>
                    <li>Ajoutez vos produits</li>
                    <li>Créez des comptes vendeurs</li>
                    <li>Commencez à enregistrer vos ventes</li>
                </ul>

                <div class="actions">
                    <a href="public/" class="btn btn-success">
                        <i class="fas fa-sign-in-alt"></i>
                        Accéder à l'application
                    </a>
                    <button onclick="deleteInstaller()" class="btn btn-primary">
                        <i class="fas fa-trash"></i>
                        Supprimer l'installateur
                    </button>
                </div>

            <?php endif; ?>
        </div>
    </div>

    <script>
        function deleteInstaller() {
            if (confirm('Êtes-vous sûr de vouloir supprimer le fichier d\'installation ?\n\nCette action est recommandée pour la sécurité mais vous ne pourrez plus réinstaller automatiquement.')) {
                fetch('<?php echo $_SERVER['PHP_SELF']; ?>?action=delete', {
                    method: 'POST'
                }).then(() => {
                    alert('Fichier d\'installation supprimé avec succès !');
                    window.location.href = 'public/';
                }).catch(() => {
                    alert('Erreur lors de la suppression. Veuillez supprimer manuellement le fichier install.php');
                });
            }
        }

        // Animation de la barre de progression
        document.addEventListener('DOMContentLoaded', function() {
            const progressFill = document.querySelector('.progress-fill');
            if (progressFill) {
                progressFill.style.width = '0%';
                setTimeout(() => {
                    progressFill.style.width = '<?php echo ($step / 6) * 100; ?>%';
                }, 300);
            }

            // Animation des étapes
            const steps = document.querySelectorAll('.step');
            steps.forEach((step, index) => {
                setTimeout(() => {
                    step.style.opacity = '0';
                    step.style.transform = 'translateY(10px)';
                    step.style.transition = 'all 0.3s ease';
                    
                    setTimeout(() => {
                        step.style.opacity = '1';
                        step.style.transform = 'translateY(0)';
                    }, 50);
                }, index * 100);
            });
        });
    </script>
</body>
</html>

<?php
// Traitement de la suppression de l'installateur
if (isset($_GET['action']) && $_GET['action'] === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    unlink(__FILE__);
    exit('OK');
}
?>