# 📊 Système de Suivi des Ventes

**Projet de Développement - BTS Informatique Génie Logiciel**  
*Période : 21 au 26 juillet 2025*

## 🎯 Objectif du Projet

Ce logiciel permet la saisie quotidienne des ventes et l'édition de récapitulatifs en fonction de critères tels que :
- Date de vente
- Désignation du type de produit
- Nom du produit

## 🔧 Technologies Utilisées

- **Backend :** PHP 8+ avec PDO
- **Frontend :** HTML5, CSS3, JavaScript (Vanilla)
- **Base de données :** MySQL 8+
- **Graphiques :** Chart.js
- **Icons :** Font Awesome 6
- **Architecture :** MVC (Model-View-Controller)

## 📋 Fonctionnalités Principales

### 🏠 Dashboard
- Vue d'ensemble des ventes du jour
- Statistiques des 30 derniers jours
- Graphiques d'évolution des ventes
- Alertes de stock faible
- Actions rapides

### 👥 Gestion des Utilisateurs
- **Administrateur :**
  - Créer des utilisateurs (vendeurs)
  - Enregistrer produits et catégories
  - Enregistrer les ventes
  - Consulter tous les récapitulatifs
  - Gérer les permissions

- **Vendeur :**
  - Saisir les ventes quotidiennes
  - Consulter ses propres ventes
  - Voir les récapitulatifs

### 📦 Gestion des Produits
- CRUD complet des produits
- Gestion des catégories
- Suivi des stocks en temps réel
- Alertes automatiques de rupture
- SKU automatique

### 💰 Gestion des Ventes
- Enregistrement des transactions
- Validation des stocks
- Historique complet
- Filtrage avancé
- Export des données

### 📈 Rapports et Statistiques
- Récapitulatifs par période
- Produits les plus vendus
- Performance des vendeurs
- Évolution mensuelle
- Export CSV/PDF

## 🛠️ Installation

### Prérequis
- **Serveur Web :** Apache/Nginx
- **PHP :** Version 8.0 ou supérieure
- **MySQL :** Version 8.0 ou supérieure
- **Extensions PHP requises :**
  - PDO
  - PDO_MySQL
  - mbstring
  - json
  - session

### Étapes d'Installation

#### 1. Clonage du Projet

```bash
git clone https://github.com/votre-repo/suivi-ventes.git
cd suivi-ventes
```

#### 2. Configuration de la Base de Données

1. Créer une base de données MySQL :

```sql
CREATE DATABASE suivi_vente CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
```

2. Importer le schéma principal :

```bash
mysql -u root -p suivi_vente < database/suivi_vente.sql
```

3. Exécuter le script de configuration avancée :

```bash
mysql -u root -p suivi_vente < database/setup.sql
```

#### 3. Configuration de l'Application

1. Modifier le fichier `config/database.php` :

```php
private $host = 'localhost';        // Votre host MySQL
private $db_name = 'suivi_vente';   // Nom de votre base
private $username = 'root';         // Votre utilisateur MySQL
private $password = '';             // Votre mot de passe MySQL
```

2. Modifier `config/config.php` pour l'URL de base :

```php
const BASE_URL = "http://localhost/suivi-ventes/public/";
```

#### 4. Configuration du Serveur Web

**Pour Apache (.htaccess) :**

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

# Sécurité
<Files "*.php">
    Order allow,deny
    Allow from all
</Files>

<Files "config/*">
    Order deny,allow
    Deny from all
</Files>
```

**Pour Nginx :**

```nginx
server {
    listen 80;
    server_name localhost;
    root /path/to/suivi-ventes/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

#### 5. Permissions des Fichiers

```bash
# Donner les bonnes permissions
chmod -R 755 suivi-ventes/
chmod -R 775 suivi-ventes/logs/
chmod -R 775 suivi-ventes/uploads/
```

## 🚀 Utilisation

### Premier Démarrage

1. **Accédez à l'application :** `http://localhost/suivi-ventes/public/`

2. **Connectez-vous avec le super admin :**
   - **Utilisateur :** `superadmin`
   - **Mot de passe :** `admin123`

3. **Changez immédiatement le mot de passe par défaut !**

### Comptes de Test Disponibles

| Utilisateur | Mot de passe | Rôle | Description |
|-------------|--------------|------|-------------|
| `admin` | `admin123` | Administrateur | Accès complet |
| `pierre` | `admin123` | Vendeur | Ventes uniquement |
| `marcel` | `admin123` | Vendeur | Ventes uniquement |
| `jean` | `admin123` | Vendeur | Ventes uniquement |

### Workflow Typique

#### Pour un Administrateur :
1. **Créer les catégories** de produits
2. **Ajouter les produits** avec leurs stocks
3. **Créer les utilisateurs** vendeurs
4. **Configurer les permissions**
5. **Superviser les ventes** et consulter les rapports

#### Pour un Vendeur :
1. **Se connecter** au système
2. **Enregistrer les ventes** quotidiennes
3. **Consulter l'historique** de ses ventes
4. **Vérifier les stocks** disponibles

### Gestion des Ventes

#### Enregistrer une Vente :
1. Aller sur **"Nouvelle Vente"**
2. Sélectionner le **produit**
3. Saisir la **quantité** (en kg)
4. Vérifier le **prix unitaire** (modifiable)
5. Confirmer la **date de vente**
6. **Valider** la transaction

Le système vérifie automatiquement :
- ✅ Stock disponible
- ✅ Données cohérentes
- ✅ Mise à jour du stock
- ✅ Calcul du montant total

### Rapports et Statistiques

#### Types de Rapports Disponibles :
- **Rapport quotidien :** Ventes du jour
- **Rapport périodique :** Ventes par période
- **Top produits :** Produits les plus vendus
- **Performance vendeurs :** Chiffre d'affaires par vendeur
- **Évolution mensuelle :** Tendances sur 12 mois

#### Filtres Disponibles :
- 📅 **Par date :** Période personnalisée
- 📦 **Par produit :** Produit spécifique
- 🏷️ **Par catégorie :** Type de produit
- 👤 **Par vendeur :** (Administrateurs uniquement)

## 🔒 Sécurité

### Mesures Implémentées

- **Authentification sécurisée :** Mots de passe hashés (bcrypt)
- **Système de permissions :** Contrôle d'accès granulaire
- **Protection CSRF :** Tokens de sécurité
- **Validation des données :** Côté client et serveur
- **Logging des actions :** Traçabilité complète
- **Limitation du taux :** Protection contre les attaques
- **En-têtes de sécurité :** XSS, Clickjacking, etc.

### Bonnes Pratiques

1. **Changez immédiatement** les mots de passe par défaut
2. **Utilisez HTTPS** en production
3. **Sauvegardez régulièrement** la base de données
4. **Mettez à jour** les dépendances régulièrement
5. **Surveillez les logs** d'activité

## 📁 Structure du Projet

```
suivi-ventes/
├── 📁 config/
│   ├── database.php          # Configuration base de données
│   └── config.php            # Configuration générale
├── 📁 controllers/
│   ├── AuthController.php    # Gestion authentification
│   ├── ProductController.php # Gestion produits
│   ├── SaleController.php    # Gestion ventes
│   └── ...
├── 📁 models/
│   ├── User.php             # Modèle utilisateur
│   ├── Product.php          # Modèle produit
│   ├── Sale.php             # Modèle vente
│   ├── Category.php         # Modèle catégorie
│   └── ...
├── 📁 pages/
│   ├── dashboard.php        # Tableau de bord
│   ├── add-sale.php         # Nouvelle vente
│   ├── products.php         # Gestion produits
│   ├── login.php            # Connexion
│   └── ...
├── 📁 public/
│   ├── index.php            # Point d'entrée
│   ├── assets/              # Ressources statiques
│   └── .htaccess            # Configuration Apache
├── 📁 database/
│   ├── suivi_vente.sql      # Schéma principal
│   └── setup.sql            # Configuration avancée
├── 📁 api/
│   └── ...                  # Endpoints API
├── 📁 components/
│   └── ...                  # Composants réutilisables
├── 📁 logs/
│   └── ...                  # Fichiers de logs
└── README.md                # Cette documentation
```

## 🔧 Configuration Avancée

### Variables d'Environnement

Créer un fichier `.env` (optionnel) :

```env
DB_HOST=localhost
DB_NAME=suivi_vente
DB_USER=root
DB_PASS=
APP_URL=http://localhost/suivi-ventes/public/
APP_ENV=development
DEBUG=true
```

### Configuration des Alertes

Les alertes de stock peuvent être configurées dans `system_settings` :

```sql
UPDATE system_settings 
SET setting_value = '5' 
WHERE setting_key = 'low_stock_threshold';
```

### Sauvegarde Automatique

Script de sauvegarde quotidienne (à ajouter au cron) :

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mysqldump -u root -p suivi_vente > /backup/suivi_vente_$DATE.sql
```

## 🐛 Débogage

### Logs d'Erreurs

Les erreurs sont enregistrées dans :
- **PHP :** `/logs/php_errors.log`
- **Application :** Table `user_logs`
- **Serveur :** Logs Apache/Nginx

### Mode Debug

Activer le debug en modifiant `config/config.php` :

```php
// Configuration des erreurs (à désactiver en production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

### Problèmes Courants

| Problème | Solution |
|----------|----------|
| **Page blanche** | Vérifier les logs PHP |
| **Erreur 500** | Permissions des fichiers |
| **Connexion DB** | Vérifier config/database.php |
| **Assets manquants** | Vérifier l'URL de base |
| **Sessions** | Permissions du dossier sessions |

## 📊 Performance

### Optimisations Implémentées

- **Index de base de données** optimisés
- **Requêtes préparées** (protection injection SQL)
- **Pagination** des résultats
- **Cache des sessions**
- **Compression des assets**

### Monitoring

Surveiller les performances via :
- **Slow Query Log** MySQL
- **Monitoring des processus** PHP
- **Statistiques d'utilisation** dans l'app

## 🔄 Maintenance

### Tâches Régulières

- **Nettoyage des logs** (automatique via events MySQL)
- **Sauvegarde des données**
- **Mise à jour des dépendances**
- **Vérification des performances**

### Scripts de Maintenance

```sql
-- Nettoyage manuel des anciennes données
CALL sp_cleanup_old_data();

-- Statistiques avancées pour une période
CALL sp_advanced_stats('2025-01-01', '2025-12-31', NULL);
```

## 📞 Support et Contact

### Développeur
- **Nom :** [Votre Nom]
- **Email :** [votre.email@example.com]
- **GitHub :** [votre-username]

### Documentation Technique
- **API Documentation :** `/docs/api.md`
- **Database Schema :** `/docs/database.md`
- **Deployment Guide :** `/docs/deployment.md`

## 📝 Licence

Ce projet est développé dans le cadre du cursus BTS Informatique - Génie Logiciel.

## 🙏 Remerciements

- **GUEMTUE Serge** - Urbaniste des SI
- **Équipe pédagogique** BTS Informatique
- **Communauté Open Source** pour les outils utilisés

---

**"Des modèles clairs, du code solide - voilà les piliers des SI qui durent."**  
*GUEMTUE Serge – Urbaniste des SI*

---

*Dernière mise à jour : 28 juillet 2025*