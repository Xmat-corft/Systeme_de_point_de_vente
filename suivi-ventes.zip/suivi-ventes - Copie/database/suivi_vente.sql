-- Script de configuration avancée pour le système de suivi des ventes
-- À exécuter après avoir importé suivi_vente.sql

USE `suivi_vente`;

-- Table des logs utilisateur pour l'audit
CREATE TABLE IF NOT EXISTS `user_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des paramètres système
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL UNIQUE,
  `setting_value` text,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` boolean DEFAULT FALSE,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des sessions (optionnelle, pour le stockage des sessions en DB)
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `last_activity` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_last_activity` (`last_activity`),
  FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table pour les sauvegardes automatiques
CREATE TABLE IF NOT EXISTS `backup_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `backup_type` enum('manual','automatic','scheduled') DEFAULT 'manual',
  `file_name` varchar(255) NOT NULL,
  `file_size` bigint DEFAULT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `error_message` text,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`created_by`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des alertes stock
CREATE TABLE IF NOT EXISTS `stock_alerts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `alert_type` enum('low_stock','out_of_stock','reorder') DEFAULT 'low_stock',
  `threshold_value` decimal(10,2) DEFAULT NULL,
  `current_stock` decimal(10,2) DEFAULT NULL,
  `is_active` boolean DEFAULT TRUE,
  `is_resolved` boolean DEFAULT FALSE,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_created_at` (`created_at`),
  FOREIGN KEY (`product_id`) REFERENCES `produit` (`NumProduit`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Ajout de colonnes utiles à la table vente pour plus de flexibilité
ALTER TABLE `vente` 
ADD COLUMN IF NOT EXISTS `discount_amount` decimal(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS `tax_amount` decimal(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS `notes` text,
ADD COLUMN IF NOT EXISTS `status` enum('pending','completed','cancelled','refunded') DEFAULT 'completed',
ADD COLUMN IF NOT EXISTS `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Ajout d'index pour optimiser les performances
ALTER TABLE `vente` 
ADD INDEX IF NOT EXISTS `idx_datevente` (`datevente`),
ADD INDEX IF NOT EXISTS `idx_status` (`status`),
ADD INDEX IF NOT EXISTS `idx_created_at` (`created_at`);

-- Ajout de colonnes utiles à la table produit
ALTER TABLE `produit`
ADD COLUMN IF NOT EXISTS `description` text,
ADD COLUMN IF NOT EXISTS `sku` varchar(50) UNIQUE,
ADD COLUMN IF NOT EXISTS `min_stock_level` decimal(10,2) DEFAULT 10,
ADD COLUMN IF NOT EXISTS `max_stock_level` decimal(10,2) DEFAULT 1000,
ADD COLUMN IF NOT EXISTS `is_active` boolean DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Index pour optimiser les recherches produits
ALTER TABLE `produit`
ADD INDEX IF NOT EXISTS `idx_sku` (`sku`),
ADD INDEX IF NOT EXISTS `idx_is_active` (`is_active`),
ADD INDEX IF NOT EXISTS `idx_min_stock` (`min_stock_level`);

-- Ajout de colonnes à la table utilisateur
ALTER TABLE `utilisateur`
ADD COLUMN IF NOT EXISTS `email` varchar(255) UNIQUE,
ADD COLUMN IF NOT EXISTS `first_name` varchar(100),
ADD COLUMN IF NOT EXISTS `last_name` varchar(100),
ADD COLUMN IF NOT EXISTS `phone` varchar(20),
ADD COLUMN IF NOT EXISTS `is_active` boolean DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS `last_login` timestamp NULL DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Index pour optimiser les recherches utilisateurs
ALTER TABLE `utilisateur`
ADD INDEX IF NOT EXISTS `idx_email` (`email`),
ADD INDEX IF NOT EXISTS `idx_is_active` (`is_active`),
ADD INDEX IF NOT EXISTS `idx_last_login` (`last_login`);

-- Insertion des paramètres système par défaut
INSERT IGNORE INTO `system_settings` (`setting_key`, `setting_value`, `description`) VALUES
('app_name', 'Système de Suivi des Ventes', 'Nom de l\'application'),
('app_version', '1.0.0', 'Version de l\'application'),
('currency', 'FCFA', 'Devise utilisée'),
('timezone', 'Africa/Douala', 'Fuseau horaire'),
('date_format', 'd/m/Y', 'Format d\'affichage des dates'),
('items_per_page', '20', 'Nombre d\'éléments par page'),
('low_stock_threshold', '10', 'Seuil d\'alerte stock faible'),
('backup_retention_days', '30', 'Nombre de jours de rétention des sauvegardes'),
('session_timeout', '3600', 'Durée de session en secondes'),
('max_login_attempts', '3', 'Nombre maximum de tentatives de connexion'),
('maintenance_mode', '0', 'Mode maintenance (0=off, 1=on)'),
('allow_registration', '0', 'Autoriser l\'auto-inscription'),
('default_user_role', 'vendeur', 'Rôle par défaut des nouveaux utilisateurs');

-- Mise à jour des permissions existantes avec de nouvelles permissions
INSERT IGNORE INTO `permission` (`typePermission`) VALUES
('voir_logs'),
('exporter_donnees'),
('importer_donnees'),
('gerer_sauvegardes'),
('voir_statistiques_avancees'),
('gerer_parametres_systeme'),
('voir_tous_utilisateurs'),
('modifier_permissions'),
('voir_notifications'),
('envoyer_notifications');

-- Création d'un super admin par défaut (mot de passe: admin123)
INSERT IGNORE INTO `utilisateur` (`nomutilisateur`, `motdepasse`, `email`, `first_name`, `last_name`) 
VALUES ('superadmin', '$2y$10$Sfrl0xMFlVfSFB6kVREgx.dqLyAg2ObRA7qTkAxTwkt6H7UbwEJ/m', 'admin@suiviventes.local', 'Super', 'Admin');

-- Assigner le rôle admin au super admin
INSERT IGNORE INTO `roleutilisateur` (`idUtilisateur`, `idRole`) 
SELECT u.idUtilisateur, r.idRole 
FROM `utilisateur` u, `role` r 
WHERE u.nomutilisateur = 'superadmin' AND r.NomRole = 'admin';

-- Assigner toutes les permissions au rôle admin
INSERT IGNORE INTO `rolepermission` (`idRole`, `idPermission`)
SELECT r.idRole, p.idPermission 
FROM `role` r, `permission` p 
WHERE r.NomRole = 'admin';

-- Assigner les permissions de base au rôle vendeur
INSERT IGNORE INTO `rolepermission` (`idRole`, `idPermission`)
SELECT r.idRole, p.idPermission 
FROM `role` r, `permission` p 
WHERE r.NomRole = 'vendeur' 
AND p.typePermission IN (
    'enregistrer_vente',
    'selectionner_vente',
    'selectionner_produit',
    'selectionner_categorie'
);

-- Création de vues utiles pour les rapports
CREATE OR REPLACE VIEW `v_sales_summary` AS
SELECT 
    v.idvente,
    v.datevente,
    v.quantite,
    v.prix_unitaire,
    (v.quantite * v.prix_unitaire) as montant_total,
    p.NomProduit,
    c.designation as categorie,
    u.nomutilisateur as vendeur,
    u.first_name,
    u.last_name,
    v.status,
    v.created_at
FROM vente v
LEFT JOIN produit p ON v.NumProduit = p.NumProduit
LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
LEFT JOIN utilisateur u ON v.idUtilisateur = u.idUtilisateur;

-- Vue pour les statistiques produits
CREATE OR REPLACE VIEW `v_product_stats` AS
SELECT 
    p.NumProduit,
    p.NomProduit,
    p.quantiteProduit as stock_actuel,
    p.prix_par_Kg,
    c.designation as categorie,
    COALESCE(SUM(v.quantite), 0) as total_vendu,
    COALESCE(COUNT(v.idvente), 0) as nb_ventes,
    COALESCE(SUM(v.quantite * v.prix_unitaire), 0) as ca_total,
    p.min_stock_level,
    CASE 
        WHEN p.quantiteProduit <= p.min_stock_level THEN 'low'
        WHEN p.quantiteProduit <= (p.min_stock_level * 2) THEN 'medium'
        ELSE 'high'
    END as stock_status,
    p.is_active,
    p.created_at,
    p.updated_at
FROM produit p
LEFT JOIN categorie c ON p.id_categorie = c.id_categorie
LEFT JOIN vente v ON p.NumProduit = v.NumProduit
GROUP BY p.NumProduit;

-- Vue pour les performances vendeurs
CREATE OR REPLACE VIEW `v_seller_performance` AS
SELECT 
    u.idUtilisateur,
    u.nomutilisateur,
    CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) as nom_complet,
    COUNT(v.idvente) as nb_ventes,
    COALESCE(SUM(v.quantite * v.prix_unitaire), 0) as ca_total,
    COALESCE(AVG(v.quantite * v.prix_unitaire), 0) as panier_moyen,
    DATE(MAX(v.datevente)) as derniere_vente,
    u.is_active,
    u.created_at as date_creation
FROM utilisateur u
LEFT JOIN vente v ON u.idUtilisateur = v.idUtilisateur
WHERE u.idUtilisateur IN (
    SELECT DISTINCT ru.idUtilisateur 
    FROM roleutilisateur ru 
    INNER JOIN role r ON ru.idRole = r.idRole 
    WHERE r.NomRole IN ('vendeur', 'admin')
)
GROUP BY u.idUtilisateur;

-- Procédure stockée pour calculer les statistiques mensuelles
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_monthly_stats`(IN target_month INT, IN target_year INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_date DATE;
    DECLARE v_total DECIMAL(15,2);
    DECLARE v_count INT;
    
    SELECT 
        COUNT(*) as nb_ventes,
        COALESCE(SUM(quantite * prix_unitaire), 0) as ca_total,
        COALESCE(AVG(quantite * prix_unitaire), 0) as panier_moyen,
        COUNT(DISTINCT idUtilisateur) as nb_vendeurs_actifs,
        COUNT(DISTINCT NumProduit) as nb_produits_vendus
    FROM vente 
    WHERE MONTH(datevente) = target_month 
    AND YEAR(datevente) = target_year;
END //
DELIMITER ;

-- Fonction pour générer un SKU automatique
DELIMITER //
CREATE FUNCTION IF NOT EXISTS `generate_sku`(category_id INT, product_name VARCHAR(100))
RETURNS VARCHAR(50)
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE category_code VARCHAR(10);
    DECLARE name_code VARCHAR(10);
    DECLARE counter INT;
    DECLARE new_sku VARCHAR(50);
    
    -- Obtenir le code catégorie (3 premières lettres)
    SELECT UPPER(LEFT(designation, 3)) INTO category_code 
    FROM categorie WHERE id_categorie = category_id;
    
    -- Obtenir le code produit (3 premières lettres)
    SET name_code = UPPER(LEFT(REPLACE(product_name, ' ', ''), 3));
    
    -- Compter les produits existants avec ce préfixe
    SELECT COUNT(*) + 1 INTO counter 
    FROM produit 
    WHERE sku LIKE CONCAT(category_code, name_code, '%');
    
    -- Générer le SKU final
    SET new_sku = CONCAT(category_code, name_code, LPAD(counter, 3, '0'));
    
    RETURN new_sku;
END //
DELIMITER ;

-- Trigger pour générer automatiquement un SKU lors de l'insertion d'un produit
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `tr_product_sku_insert`
BEFORE INSERT ON `produit`
FOR EACH ROW
BEGIN
    IF NEW.sku IS NULL OR NEW.sku = '' THEN
        SET NEW.sku = generate_sku(NEW.id_categorie, NEW.NomProduit);
    END IF;
END //
DELIMITER ;

-- Trigger pour créer une alerte stock automatiquement
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `tr_stock_alert`
AFTER UPDATE ON `produit`
FOR EACH ROW
BEGIN
    -- Vérifier si le stock est passé en dessous du seuil minimum
    IF NEW.quantiteProduit <= NEW.min_stock_level AND OLD.quantiteProduit > NEW.min_stock_level THEN
        INSERT INTO stock_alerts (product_id, alert_type, threshold_value, current_stock)
        VALUES (NEW.NumProduit, 'low_stock', NEW.min_stock_level, NEW.quantiteProduit);
    END IF;
    
    -- Résoudre l'alerte si le stock remonte
    IF NEW.quantiteProduit > NEW.min_stock_level AND OLD.quantiteProduit <= NEW.min_stock_level THEN
        UPDATE stock_alerts 
        SET is_resolved = TRUE, resolved_at = NOW()
        WHERE product_id = NEW.NumProduit AND is_resolved = FALSE;
    END IF;
END //
DELIMITER ;

-- Trigger pour mettre à jour last_login
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `tr_update_last_login`
AFTER UPDATE ON `utilisateur`
FOR EACH ROW
BEGIN
    -- Ce trigger serait déclenché par le code PHP lors de la connexion
    -- On peut aussi l'utiliser pour d'autres mises à jour automatiques
    IF NEW.nomutilisateur != OLD.nomutilisateur THEN
        INSERT INTO user_logs (user_id, action, details)
        VALUES (NEW.idUtilisateur, 'username_changed', CONCAT('Ancien: ', OLD.nomutilisateur, ', Nouveau: ', NEW.nomutilisateur));
    END IF;
END //
DELIMITER ;

-- Trigger pour logger les suppressions importantes
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `tr_log_product_deletion`
BEFORE DELETE ON `produit`
FOR EACH ROW
BEGIN
    INSERT INTO user_logs (user_id, action, details)
    VALUES (
        @current_user_id, -- Cette variable devra être définie dans le code PHP
        'product_deleted',
        CONCAT('Produit supprimé: ', OLD.NomProduit, ' (ID: ', OLD.NumProduit, ')')
    );
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER IF NOT EXISTS `tr_log_sale_deletion`
BEFORE DELETE ON `vente`
FOR EACH ROW
BEGIN
    INSERT INTO user_logs (user_id, action, details)
    VALUES (
        @current_user_id,
        'sale_deleted',
        CONCAT('Vente supprimée: ID ', OLD.idvente, ', Montant: ', (OLD.quantite * OLD.prix_unitaire))
    );
END //
DELIMITER ;
DELIMITER ;

-- Index composites pour optimiser les requêtes fréquentes
CREATE INDEX IF NOT EXISTS `idx_vente_date_user` ON `vente` (`datevente`, `idUtilisateur`);
CREATE INDEX IF NOT EXISTS `idx_vente_product_date` ON `vente` (`NumProduit`, `datevente`);
CREATE INDEX IF NOT EXISTS `idx_produit_category_active` ON `produit` (`id_categorie`, `is_active`);
CREATE INDEX IF NOT EXISTS `idx_user_logs_user_date` ON `user_logs` (`user_id`, `created_at`);

-- Mise à jour des données existantes pour les nouvelles colonnes
UPDATE `produit` SET `min_stock_level` = 10 WHERE `min_stock_level` IS NULL;
UPDATE `produit` SET `max_stock_level` = 1000 WHERE `max_stock_level` IS NULL;
UPDATE `produit` SET `is_active` = TRUE WHERE `is_active` IS NULL;
UPDATE `utilisateur` SET `is_active` = TRUE WHERE `is_active` IS NULL;
UPDATE `vente` SET `status` = 'completed' WHERE `status` IS NULL;

-- Génération des SKU pour les produits existants
UPDATE `produit` p 
LEFT JOIN `categorie` c ON p.id_categorie = c.id_categorie
SET p.sku = generate_sku(p.id_categorie, p.NomProduit)
WHERE p.sku IS NULL OR p.sku = '';

-- Création d'alertes pour les produits actuellement en rupture
INSERT INTO `stock_alerts` (product_id, alert_type, threshold_value, current_stock)
SELECT 
    NumProduit,
    CASE 
        WHEN quantiteProduit = 0 THEN 'out_of_stock'
        ELSE 'low_stock'
    END,
    min_stock_level,
    quantiteProduit
FROM `produit`
WHERE quantiteProduit <= min_stock_level
AND NumProduit NOT IN (SELECT product_id FROM stock_alerts WHERE is_resolved = FALSE);

-- Procédure pour nettoyer les anciennes données
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_cleanup_old_data`()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Supprimer les logs de plus de 90 jours
    DELETE FROM `user_logs` WHERE `created_at` < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- Supprimer les notifications lues de plus de 30 jours
    DELETE FROM `notifications` 
    WHERE `is_read` = TRUE AND `created_at` < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- Supprimer les sessions expirées
    DELETE FROM `user_sessions` 
    WHERE `last_activity` < DATE_SUB(NOW(), INTERVAL 24 HOUR);
    
    -- Supprimer les alertes stock résolues de plus de 7 jours
    DELETE FROM `stock_alerts` 
    WHERE `is_resolved` = TRUE AND `resolved_at` < DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    COMMIT;
    
    SELECT 'Nettoyage terminé avec succès' as message;
END //
DELIMITER ;

-- Procédure pour les statistiques avancées
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_advanced_stats`(
    IN start_date DATE,
    IN end_date DATE,
    IN user_id INT
)
BEGIN
    -- Statistiques générales
    SELECT 'Statistiques générales' as section;
    
    SELECT 
        COUNT(*) as total_ventes,
        SUM(quantite * prix_unitaire) as ca_total,
        AVG(quantite * prix_unitaire) as panier_moyen,
        COUNT(DISTINCT NumProduit) as produits_vendus,
        COUNT(DISTINCT idUtilisateur) as vendeurs_actifs
    FROM vente v
    WHERE v.datevente BETWEEN start_date AND end_date
    AND (user_id IS NULL OR v.idUtilisateur = user_id);
    
    -- Top 10 des produits
    SELECT 'Top 10 produits' as section;
    
    SELECT 
        p.NomProduit,
        SUM(v.quantite) as quantite_totale,
        SUM(v.quantite * v.prix_unitaire) as ca_produit,
        COUNT(v.idvente) as nb_transactions
    FROM vente v
    JOIN produit p ON v.NumProduit = p.NumProduit
    WHERE v.datevente BETWEEN start_date AND end_date
    AND (user_id IS NULL OR v.idUtilisateur = user_id)
    GROUP BY v.NumProduit, p.NomProduit
    ORDER BY ca_produit DESC
    LIMIT 10;
    
    -- Évolution quotidienne
    SELECT 'Évolution quotidienne' as section;
    
    SELECT 
        DATE(v.datevente) as date_vente,
        COUNT(*) as nb_ventes,
        SUM(v.quantite * v.prix_unitaire) as ca_jour
    FROM vente v
    WHERE v.datevente BETWEEN start_date AND end_date
    AND (user_id IS NULL OR v.idUtilisateur = user_id)
    GROUP BY DATE(v.datevente)
    ORDER BY date_vente;
END //
DELIMITER ;

-- Event pour le nettoyage automatique (exécuté chaque dimanche à 2h du matin)
CREATE EVENT IF NOT EXISTS `ev_weekly_cleanup`
ON SCHEDULE EVERY 1 WEEK
STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 WEEK + INTERVAL 2 HOUR)
DO CALL sp_cleanup_old_data();

-- Event pour générer des alertes de stock quotidiennes
DELIMITER //
CREATE EVENT IF NOT EXISTS `ev_daily_stock_check`
ON SCHEDULE EVERY 1 DAY
STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 DAY + INTERVAL 6 HOUR)
DO
BEGIN
    -- Créer des notifications pour les administrateurs sur les stocks faibles
    INSERT INTO notifications (user_id, title, message, type)
    SELECT 
        u.idUtilisateur,
        'Alerte Stock Faible',
        CONCAT('Le produit "', p.NomProduit, '" a un stock de ', p.quantiteProduit, ' kg (seuil: ', p.min_stock_level, ' kg)'),
        'warning'
    FROM produit p
    CROSS JOIN (
        SELECT u.idUtilisateur 
        FROM utilisateur u
        JOIN roleutilisateur ru ON u.idUtilisateur = ru.idUtilisateur
        JOIN role r ON ru.idRole = r.idRole
        WHERE r.NomRole = 'admin' AND u.is_active = TRUE
    ) u
    WHERE p.quantiteProduit <= p.min_stock_level
    AND p.is_active = TRUE
    AND NOT EXISTS (
        SELECT 1 FROM notifications n
        WHERE n.user_id = u.idUtilisateur
        AND n.message LIKE CONCAT('%', p.NomProduit, '%')
        AND DATE(n.created_at) = CURDATE()
    );
END //
DELIMITER ;

-- Activer les events si ce n'est pas déjà fait
SET GLOBAL event_scheduler = ON;

-- Insertion de données de test supplémentaires (optionnel)
-- Décommenter si vous voulez des données de test

/*
-- Ajout de quelques ventes de test pour les 30 derniers jours
INSERT INTO `vente` (datevente, quantite, prix_unitaire, NumProduit, idUtilisateur, status) VALUES
(DATE_SUB(CURDATE(), INTERVAL 1 DAY), 5.5, 2500, 1, 2, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 2 DAY), 3.0, 3000, 2, 2, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 3 DAY), 8.0, 1800, 3, 3, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 5 DAY), 2.5, 2200, 4, 2, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 7 DAY), 10.0, 1500, 5, 4, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 10 DAY), 4.5, 1900, 6, 3, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 12 DAY), 6.0, 2800, 7, 2, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 15 DAY), 7.5, 1200, 8, 4, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 18 DAY), 3.5, 4000, 9, 2, 'completed'),
(DATE_SUB(CURDATE(), INTERVAL 20 DAY), 12.0, 1300, 10, 3, 'completed');

-- Mise à jour des stocks en conséquence
UPDATE produit SET quantiteProduit = quantiteProduit - 5.5 WHERE NumProduit = 1;
UPDATE produit SET quantiteProduit = quantiteProduit - 3.0 WHERE NumProduit = 2;
UPDATE produit SET quantiteProduit = quantiteProduit - 8.0 WHERE NumProduit = 3;
UPDATE produit SET quantiteProduit = quantiteProduit - 2.5 WHERE NumProduit = 4;
UPDATE produit SET quantiteProduit = quantiteProduit - 10.0 WHERE NumProduit = 5;
UPDATE produit SET quantiteProduit = quantiteProduit - 4.5 WHERE NumProduit = 6;
UPDATE produit SET quantiteProduit = quantiteProduit - 6.0 WHERE NumProduit = 7;
UPDATE produit SET quantiteProduit = quantiteProduit - 7.5 WHERE NumProduit = 8;
UPDATE produit SET quantiteProduit = quantiteProduit - 3.5 WHERE NumProduit = 9;
UPDATE produit SET quantiteProduit = quantiteProduit - 12.0 WHERE NumProduit = 10;
*/

-- Affichage du résumé de l'installation
SELECT 
    'Installation terminée!' as status,
    (SELECT COUNT(*) FROM produit) as total_produits,
    (SELECT COUNT(*) FROM categorie) as total_categories,
    (SELECT COUNT(*) FROM utilisateur) as total_utilisateurs,
    (SELECT COUNT(*) FROM role) as total_roles,
    (SELECT COUNT(*) FROM permission) as total_permissions,
    (SELECT COUNT(*) FROM vente) as total_ventes,
    (SELECT setting_value FROM system_settings WHERE setting_key = 'app_version') as version_app;

-- Messages d'information
SELECT 'Configuration de la base de données terminée avec succès!' as message;
SELECT 'Utilisateur super admin créé: superadmin / admin123' as info;
SELECT 'N\'oubliez pas de changer le mot de passe par défaut!' as warning;
SELECT 'Les events automatiques sont activés pour le nettoyage et les alertes' as note;